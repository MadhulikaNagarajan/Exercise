
from unittest import TestCase
from flask import Flask, render_template, request

from app import app

class Testfunctions(TestCase):
    def setUp(self):
        self.app = app.test_client

    def test_get_user_result(self):
        response = self.app.get('/get_user')  # Use get for a GET request
        # Assuming that your database.get_user_data() returns a string for simplicity
        expected_result = "User data fetched successfully"
        self.assertEqual(response.data.decode(), expected_result)


